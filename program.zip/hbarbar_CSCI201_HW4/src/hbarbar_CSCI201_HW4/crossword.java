package hbarbar_CSCI201_HW4;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Vector;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class crossword {

	private Vector<playerThread> playerThreads;
	private Vector<Lock> locks;
	private Vector<Condition> conditions;
	private int playersIn;
	private int maxPlayers;
	private boolean gameStarted;
	private boolean maxPlayersSet;
	ServerSocket ss;
	private int currentPlayer;
	private int state;
	
	boolean flag = true;

	private boolean across;
	private int number;
	private String guess;
	static Board board;
	private int[] scores;
	int port;
	

	private char [][] gameBoard = new char[72][80];

	public void initialRead(int port) {		
		try {
			System.out.println("\nWaiting on players...");
			//Create a vector of player threads
			playerThreads = new Vector<playerThread>();
			locks = new Vector<Lock>();
			conditions = new Vector<Condition>();			
			
			
			playersIn = 0;
			maxPlayers = 0;
			gameStarted = false;
			maxPlayersSet = true;
			currentPlayer = 0;
			state = 0;
			board = new Board();
			scores = new int[3];
			while ((gameStarted == false) && maxPlayersSet) {

				Socket s = ss.accept(); // blocking
				System.out.println("Connection from: " + s.getInetAddress());
				Lock loc  = new ReentrantLock();
				Condition c = loc.newCondition();
				if (playerThreads.size() == 0) {
					playerThread st = new playerThread(s, this, loc, c, true);
					playerThreads.add(st);
					maxPlayersSet = false;
					System.out.print("Number of players: ");
					st.sendMessage("How many players will there be?");
				} else {
					playerThread st = new playerThread(s, this, loc, c, false);
					playerThreads.add(st);
				}
				locks.add(loc);
				conditions.add(c);
				playersIn++;
			}
		} catch (IOException ioe) {
			System.out.println("ioe in ChatRoom constructor: " + ioe.getMessage());
		}
	}
	
	
	//Broadcasting the messages to the Players
	public void broadcast(String message, playerThread st) {
		//Initial state
	
		if(maxPlayersSet == false) {
			int players = Integer.parseInt(message);
			System.out.println(players);
			if(players >= 1 && players <= 3) {
				maxPlayers = players;
				maxPlayersSet = true;
				
				if(players == 2) {
					System.out.println("Waiting for player 2.");
					board.parse();
					System.out.println("Reading random game file.");
					System.out.println("File read successfully.");
					playerThreads.elementAt(0).sendMessage("Waiting for player 2.");
				}else if(players == 3) {
					System.out.println("Waiting for player 2 and player 3");
					playerThreads.elementAt(0).sendMessage("Waiting for player 2 and player 3");

				}
				if(players == 1) {
					board.parse();
					System.out.println("Reading random game file.");
					System.out.println("File read successfully.");
					playGame();
				}else {
					listenToConnections();
				}
			}else {
				st.sendMessage("Unvalid, please enter a number between 1 and 3.");
				st.sendMessage("How many players will there be?");
			}
		}else {
			checkGame(message);
		}
		
	}
	
	public void checkGame(String message) {
		if(state == 1) {
			if(message.equals("a") || message.equals("d")) {
				if(message.equals("a")) {
					across = true;
				}else {
					across = false;
				}
				state = 2;
				playGame();
			}else {
				playerThreads.elementAt(currentPlayer).sendMessage("That is not a Valid Option!");
				playerThreads.elementAt(currentPlayer).sendMessage("Would you like to answer a question across (a) or down (d)?");

			}
		}else if(state == 2) {
			if(board.validNumber(Integer.parseInt(message), across)) {
				number = Integer.parseInt(message);
				state = 3;
				playGame();
			}else {
				playerThreads.elementAt(currentPlayer).sendMessage("That is not a Valid Option!");
				playerThreads.elementAt(currentPlayer).sendMessage("Which number?");
			}
		}else if(state == 3) {
				guess = message;
				state = 4;
				playGame();
			}else {
				playerThreads.elementAt(currentPlayer).sendMessage("That is not a Valid Option!");
				playerThreads.elementAt(currentPlayer).sendMessage("What is your guess for");
			}
		}

	
	public void playGame() {
		//Print the board
		if(state == 0) {
			System.out.println("Sending game board.");
			printBoard();
			if(board.isGameOver()) {
				System.out.println("The game has concluded\nSending scores.");
				sendFinalScores();
				kickClients();
				clearData();
				initialRead(3456);
			}else {
				state = 1;
			}
		}
		if(state == 1) {
			System.out.println("Player " + (currentPlayer+1) + "'s turn");
			for (playerThread threads : playerThreads) {
				if(threads == playerThreads.elementAt(currentPlayer)) {
					threads.sendMessage("Would you like to answer a question across (a) or down (d)?");
				}else {
					threads.sendMessage("Player " + (currentPlayer+1) + "'s turn");
				}
			}
		}else if(state == 2) {
			for (playerThread threads : playerThreads) {
				if(threads == playerThreads.elementAt(currentPlayer)) {
					threads.sendMessage("Which number?");
				}
			}
		}else if(state == 3) {
			for (playerThread threads : playerThreads) {
				if(threads == playerThreads.elementAt(currentPlayer)) {
					if(across) {
						threads.sendMessage("What is your guess for " + number + " across");
					}else {
						threads.sendMessage("What is your guess for " +  " for " + number + " down");
					}
				}
			}
		}else if(state == 4) {
			//Evlauets whether the guess was right or wrong
			if(across) {
				System.out.println("Player " + (currentPlayer+1) + " guessed " + guess + " for " + number + " across.");
				for (playerThread threads : playerThreads) {
					if (playerThreads.elementAt(currentPlayer) != threads) {
						threads.sendMessage("Player " + (currentPlayer+1)+ " guess " + guess + " for " + number + " across.");
					}
				}
			}else {
				System.out.println("Player " + (currentPlayer+1) + " guess " + guess + " for " + number + " down.");
				for (playerThread threads : playerThreads) {
					if (playerThreads.elementAt(currentPlayer) != threads) {
						threads.sendMessage("Player " + (currentPlayer+1) + " guess " + guess + " for " + number + " down.");
					}
				}
			}
			//If valid guess
			if(board.validGuess(guess, number, across)) {
				System.out.println("That is correct.");
				for (playerThread threads : playerThreads) {
					if (playerThreads.elementAt(currentPlayer) != threads) {
						threads.sendMessage("That is correct.");
					}else {
						threads.sendMessage("That is correct!");
					}
				}
				state = 0;
				guess = "";
				number = 0;
				scores[currentPlayer]++;
				playGame();
			}else {
				System.out.println("That is incorrect.");
				for (playerThread threads : playerThreads) {
					if (playerThreads.elementAt(currentPlayer) != threads) {
						threads.sendMessage("That is incorrect.");
					}else {
						threads.sendMessage("That is incorrect!");
					}
				}
				state = 0;
				guess = "";
				number = 0;
				
				if(maxPlayers != 1) {
					playerThreads.elementAt(currentPlayer).setFinish();
					signalAll(playerThreads.elementAt(currentPlayer));
					
				}
				if(currentPlayer == (maxPlayers - 1)) {
					currentPlayer = 0;
				}else {
					currentPlayer++;
				}
				playGame();
				//End his turn and signal next player
				
				
			}
			
		}
	}
	public void signalAll(playerThread st) {
		int index = 0;
		for (int i = 0; i < playerThreads.size(); i++) {
			if (playerThreads.elementAt(i).equals(st)) {
				index = i;
				break;
			}
		}
		if (index >= (playerThreads.size() - 1)) {
			index = 0;
		}else {
			index++;
		}
		locks.elementAt(index).lock();
		conditions.elementAt(index).signal();
		locks.elementAt(index).unlock();
	}
	
	public void printBoard() {

		String board = "";
		board = this.board.getBoard();
		
		Vector<String> qu = this.board.getQuestions();
		board += "\n";
		for(int i = 0; i < qu.size(); i++) {
			board += qu.elementAt(i);
			board += "\n";
		}
		
		for (playerThread threads : playerThreads) {
			threads.sendMessage(board);
		}
	}
	
	public void place() {
		gameBoard[1][20] = '5';
		gameBoard[1][21] = '_';
		
		gameBoard[2][21] = '_';
		gameBoard[3][21] = '_';
		gameBoard[4][21] = '_';
		gameBoard[5][21] = '_';
		gameBoard[6][21] = '_';
		gameBoard[7][21] = '_';
		gameBoard[8][21] = '_';

		gameBoard[5][14] = '1';
		gameBoard[5][15] = '_';
		gameBoard[5][16] = '_';
		gameBoard[5][17] = '_';
		gameBoard[5][18] = '_';
		gameBoard[5][19] = '_';
		gameBoard[5][20] = '_';


	}
	
	public void listenToConnections() {
		try {
			System.out.println("Waiting for players...");
			while ((gameStarted == false) && maxPlayersSet) {
				Socket s = ss.accept(); // blocking
				System.out.println("Connection from: " + s.getInetAddress());
				Lock loc  = new ReentrantLock();
				Condition c = loc.newCondition();
				playerThread st = new playerThread(s, this, loc, c, false);
				playerThreads.add(st);
				locks.add(loc);
				conditions.add(c);
				playersIn++;
				for (playerThread threads : playerThreads) {
					if (st != threads) {
						threads.sendMessage("Player " + playersIn + " has joined from " + s.getInetAddress());
					}
				}
				if(playersIn == maxPlayers) {
					for (playerThread threads : playerThreads) {
						if (st == threads) {
							threads.sendMessage("There is a game waiting for you.");
							if(playersIn == 1) {
								threads.sendMessage("Players 1 and 2 has already joined.");
							}else if(playersIn == 2) {
								threads.sendMessage("Player 2 has already joined.");
							}
						}
					}
					for (playerThread threads : playerThreads) {
						threads.sendMessage("The game is beginning.");
					}
					System.out.println("Game can now begin.");
					System.out.println("Sending game board.");
					gameStarted = true;
					playGame();
				}
			}
		} catch (IOException ioe) {
			System.out.println("ioe in ChatRoom constructor: " + ioe.getMessage());
		}
	}

	public void clearData() {
		for(int i = 0; i < playerThreads.size(); i++) {
			playerThreads.elementAt(i).interrupt();
		}
		playerThreads.clear();
		locks.clear();
		conditions.clear();
		playersIn = 0;
		maxPlayers = 0;
		gameStarted = false;
		maxPlayersSet = true;
		currentPlayer = 0;
		state = 0;
		
		for(int i = 0; i < 3; i++) {
			scores[i] = 0;
		}
		
		
		across = false;
		guess = "";
		
	}
	public int determineWinner() {
		int x = 0;
		for(int i = 0; i < scores.length; i++) {
			if(scores[i] > x) {
				x = i;
			}
		}
		return x;
	}
	public void sendFinalScores() {
		int winner = determineWinner();
		String message = "Final Scores\n";
		for(int i = 0; i < maxPlayers; i++) {
			message += "Player " + (i+1) + " - " + scores[i] + " correct answers.\n";
		}
		message += "\nPlayer " + (winner+1) + " is the winner.";
		for (playerThread threads : playerThreads) {
			threads.sendMessage(message);
		}
	}
	
	public void kickClients() {
		for(int i = 0; i < playerThreads.size(); i++) {
			playerThreads.elementAt(i).sendMessage("GAME IS OVER");
		}
	}
	
	public static void main(String[] args) {
		System.out.println("Listening on port 3456");
		crossword cr = new crossword();
		try {
			cr.ss= new ServerSocket(3456);
			cr.initialRead(3456);
		} catch (IOException e) {
			e.printStackTrace();
		}
		
	}
}