package hbarbar_CSCI201_HW4;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.Random;
import java.util.Scanner;
import java.util.Vector;

public class Board {
	char[][] table;
	char[][] temp;
	char[][] temp2;

	int x;
	int y;

	String[] across = new String[16];
	String[] down = new String[16];

	String[] answers = new String[16];
	String[] answers2 = new String[16];

	int placedAcross = 0;
	int placedDown = 0;

	Vector<String> words;

	Vector<String> AC = new Vector<String>();
	Vector<String> DN = new Vector<String>();

	Vector<String> remaningA = new Vector<String>();
	Vector<String> remaningD = new Vector<String>();

	Vector<Integer> pairsNumbers = new Vector<Integer>();
	
	String[] positionsA = new String[16];
	String[] positionsD = new String[16];
	
	Vector<String> questions = new Vector<String>();

	public int totalWords;
	
	Vector<Integer> AC2= new Vector<Integer>();
	Vector<Integer> DN2= new Vector<Integer>();


	
	public void parse() {

		try {
			FileReader fr;
			BufferedReader br;
			Scanner scan = new Scanner(System.in);
			String filename = "src/gamedata/data.txt";
			
			//code that looks at random file
		    File dir = new File("/Users/Matt/eclipse-workspace/hbarbar_CSCI201_HW4/src/gamedata");
		    File[] list = dir.listFiles();
		    Random rand = new Random();
		    File file = list[rand.nextInt(list.length)];
		    if(list.length == 0) {
		    	System.out.println("File read unsuccessfully! No valid board");
		    	System.exit(0);
		    }
		    
			fr = new FileReader(filename);
			br = new BufferedReader(fr);
			String line = br.readLine();

			int rows = 0;
			int colum = 0;

			String[] parameters;
			words = new Vector<String>();
			totalWords = 0;

			boolean ac = true;
			// Parse the data
			while (line != null) {
				parameters = line.split("[|]");
				if (parameters[0].contentEquals("DOWN")) {
					ac = false;
				}
				if(parameters.length == 1) {
					questions.add(parameters[0]);
				}
				if (parameters.length > 1) {
					if (ac) {
						across[Integer.parseInt(parameters[0])] = parameters[1];
						answers[Integer.parseInt(parameters[0])] = parameters[2];
						AC2.add(Integer.parseInt(parameters[0]));
						rows += parameters[1].length();
						AC.add(parameters[1]);
						totalWords += 1;
						questions.add(Integer.parseInt(parameters[0]) + " " + parameters[2]);
					} else {
						DN2.add(Integer.parseInt(parameters[0]));
						down[Integer.parseInt(parameters[0])] = parameters[1];
						answers2[Integer.parseInt(parameters[0])] = parameters[2];
						colum += parameters[1].length();
						DN.add(parameters[1]);
						questions.add(Integer.parseInt(parameters[0]) + " " + parameters[2]);
						totalWords += 1;
					}
				}
				line = br.readLine();
			}

			// Size of the table
			x = rows * 4 - 1;
			y = colum * 4 - 1;
			table = new char[rows * 4][colum * 4];
			temp = new char[rows * 4][colum * 4];
			temp2 = new char[rows * 4][colum * 4];

			// Starting x and Y
			int startX = rows;
			int startY = colum;
			
			remaningA = AC;
			remaningD = DN;

			for (int i = 0; i < 16; i++) {
				if (i < AC.size()) {
					words.add(AC.elementAt(i));
				}
				if (i < DN.size()) {
					words.add(DN.elementAt(i));
				}
			}
			for(int i = 0; i < 16; i++) {
				if(across[i] != null && down[i] != null) {
					pairsNumbers.add(i);
				}
			}
			Vector<String> worrr = new Vector<String>();
			worrr = words;

			
			/*
			int index = findIndex("trojans", isAcross("trojans"));
			//Find the next word to place
			for(int i = 0; i < worrr.size(); i++) {
				int index2 = findIndex(worrr.elementAt(i), isAcross(worrr.elementAt(i)));
				if(index2 == index) {
					placeWord(worrr.elementAt(i), startX, startY / 2, false);
					worrr.remove(i);
					break;
				}
			}
			*/
			tempBoard();
			try {
				// generateBoard(words.elementAt(3),3);
			} finally {
			
			}

		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	public void placeWord(String word, int x, int y, boolean across) {
		int index2 = findIndex(word, across);
		char c = (char) (index2 + '0');
		temp2[x][y] = c;

		if (across == false) {
			int index = 0;
			for (int i = x; index < word.length(); i++) {
				table[i][y] = word.charAt(index);
				if (temp[i][y] == 'A' || temp[i][y] == 'D') {
					temp[i][y] = 'X';
				} else {
					temp[i][y] = 'D';
				}
				index++;
			}
		} else {
			int index = 0;

			for (int i = y; index < word.length(); i++) {
				table[x][i] = word.charAt(index);
				if (temp[x][i] == 'A' || temp[x][i] == 'D') {
					temp[x][i] = 'X';
				} else {
					temp[x][i] = 'A';
				}

				index++;
			}
		}
	}

	public boolean validPlacement(String word, int x, int y, boolean across) {
		// If it overlaps with another 'D'
		if (word.equals("dodgers") && x == 18 && y == 10) {
			return false;
		}
		
		

		int index2 = findIndex(word, across);

		if (pairsNumbers.contains(index2) == true) {
			int xx = Character.getNumericValue(temp2[x][y]);
			if (xx != index2) {
				return false;
			}
		}
		
		if (across) {
			int index = y;
			for (int i = 0; i < word.length(); i++) {
				if (temp[x][index] == 'A') {
					return false;
				}
			}

		} else {

			int index = x;

			for (int i = 0; i < word.length(); i++) {

				if (temp[index][y] == 'D') {

					return false;

				}

			}

		}

		// first check if we are at the corners

		if ((across && (y == this.y)) || (!across && (x == this.x))) {

			return false;

		}

		// Check if it will go out of bounds

		if ((across && (word.length() + y > this.y)) || (!across && (word.length() + x) > this.x)) {

			return false;

		}

		// Check if anything next to it is a word

		// Check the beg and end of the word

		if (across) {

			if (y != 0) {

				if (table[x][y - 1] != 0) {

					return false;

				}

			}

			if (word.length() + y < this.y) {

				if (table[x][word.length() + y + 1] != 0) {

					return false;

				}

			}

		} else {

			if (x != 0) {

				if (table[x - 1][y] != 0) {

					return false;

				}

			}

			if (word.length() + x < this.x) {

				if (table[word.length() + x + 1][y] != 0) {

					return false;

				}

			}

		}

		if (across) {

			int index = y;

			for (int i = 0; i < word.length(); i++) {

				if ((x) != 0) {

					if (table[x - 1][index] != 0 && temp[x - 1][index] != 'D') {

						return false;

					}

				}

				if ((x) != this.x) {

					if (table[x + 1][index] != 0 && temp[x + 1][index] != 'D') {

						return false;

					}

				}

			}

		}

		// Now check if its only bounded by empty spaces

		if (across) {

			boolean valid1 = false;

			boolean valid2 = false;

			if (x != 0) {

				for (int i = y; i < word.length(); i++) {

					if ((int) table[x - 1][i] != 0) {

						valid1 = true;

						break;

					}

				}

			}

			if (x != this.x) {

				for (int i = y; i < word.length(); i++) {

					if ((int) table[x + 1][i] != 0) {

						valid2 = true;

						break;

					}

				}

			}

			if (valid1 && valid2 == false) {

				return false;

			}

		}

		if (!across) {

			boolean valid1 = false;

			boolean valid2 = false;

			if (y != 0) {

				for (int i = x; i < word.length(); i++) {

					if ((int) table[i][y - 1] != 0) {

						valid1 = true;

						break;

					}

				}

			}

			if (y != this.y) {

				for (int i = x; i < word.length(); i++) {

					if ((int) table[i][y + 1] != 0) {

						valid2 = true;

						break;

					}

				}

			}

			if (valid1 && valid2 == false) {

				return false;

			}

		}

		// Now check if we can place it

		int index = x;

		if (across) {

			index = y;

			boolean oneCharacter = false;

			for (int i = 0; i < word.length(); i++) {

				// System.out.println("Examining at: " + index + " " + y + ". With: " +
				// word.charAt(i) + " AND " + table[index][y]);

				if (word.charAt(i) == table[x][index]) {

					oneCharacter = true;

				}

				index++;

			}

			return oneCharacter;

		} else {

			boolean oneCharacter = false;

			for (int i = 0; i < word.length(); i++) {

				// System.out.println("Examining at: " + index + " " + y + ". With: " +
				// word.charAt(i) + " AND " + table[index][y]);

				if (word.charAt(i) == table[index][y]) {

					oneCharacter = true;

				} else if (table[index][y] != 0) {

					if (word.charAt(i) != table[index][y]) {

						return false;

					}

				}

				index++;

			}

			return oneCharacter;

		}
	}

	public void removeWord(int length, int startX, int startY, boolean across) {
		if (across) {
			int index = startY;
			for (int i = 0; i < length; i++) {
				if (((table[startX + 1][index] != 0) && (table[startX + 1][index] != ' '))
						|| ((table[startX - 1][index] != ' ') && (table[startX - 1][index] != 0))) {
					
					if(table[startX-1][index] == 't') {
						temp2[startX][index] = ' ';
						table[startX][index] = 0;
						temp[startX][index] = ' ';
						continue;
					}
					
					if (temp[startX][index] == 'X') {
						temp[startX][index] = 'D';
					}
					index++;
				} else {

					temp2[startX][index] = ' ';
					table[startX][index] = 0;
					temp[startX][index] = ' ';
					index++;
				}

			}
		} else {
			int index = startX;
			for (int i = 0; i < length; i++) {
				if (((table[index][startY + 1] != 0) && (table[index][startY + 1] != ' '))
						|| ((table[index][startY - 1] != 0) && (table[index][startY - 1] != ' '))) {
					if (temp[index][startY] == 'X') {
						temp[index][startY] = 'A';
					}
					index++;
				} else {
					temp2[index][startY] = ' ';
					table[index][startY] = ' ';
					temp[index][startY] = ' ';
					index++;
				}
			}
		}
	}

	public boolean isAcross(String word) {

		for (int i = 0; i < AC.size(); i++) {
			if (AC.elementAt(i).equals(word)) {
				return true;
			}
		}

		return false;
	}

	public boolean generateBoard(Vector<String> listOfWords) {
		if (listOfWords.size() == 0) {
			return true;
		}

		// try every position
		for (int i = 0; i < this.x; i++) {
			for (int j = 0; j < this.y; j++) {
				// Try every possible words
				for (int k = 0; k < listOfWords.size(); k++) {
					if (validPlacement(listOfWords.elementAt(k), i, j, isAcross(listOfWords.elementAt(k)))) {
						String word = listOfWords.elementAt(k);
						System.out.println("Placed " + word + " at: " + i + ":" + j);
						placeWord(word, i, j, isAcross(word));
 						listOfWords.remove(word);
						if (generateBoard(listOfWords)) {
							return true;
						}
						listOfWords.add(0, word);
						removeWord(word.length(), i, j, isAcross(word));
						System.out.println("removed " + word + " at: " + i + ":" + j);

					}
				}
			}
		}
		return false;
	}

	public String getBoard() {

		int bottom = 100000;
		int top = 0;
		int left = 100000;
		int right = 0;
		
		for(int i = 0; i < x; i++) {
			for(int j = 0; j < y; j++) {
				if(table[i][j] != 0 && table[i][j] != ' '){
					if(i < bottom) {
						bottom = i;
					}
				}
			}
		}
		
		for(int i = x; i > 0; i--) {
			for(int j = 0; j < y; j++) {
				if(table[i][j] != 0 && table[i][j] != ' '){
					if(i > top) {
						top = i;
					}
				}
			}
		}
		
		for(int j = 0; j < y; j++) {
			for(int i = 0; i < x; i++) {
				if(table[i][j] != 0 && table[i][j] != ' '){
					right = i+2;
					break;
				}
			}
		}
		for(int j = 0; j < y; j++) {
			for(int i = 0; i < x; i++) {
				if(table[i][j] != 0 && table[i][j] != ' '){
					left = j - 1;
					j = y;
				}
			}
		}
		String s = "";
		// Print the board
		for (int i = bottom; i < top+1; i++) {
			for (int j = left; j < right+1; j++) {
				
				if( Character.getNumericValue(table[i][j]) <= 16 && Character.getNumericValue(table[i][j]) >= 0){
					s += table[i][j];
					continue;
				}
				
				if ((int) table[i][j] == 0 || table[i][j] == ' ') {
					s += "-";
				} else {
					s += table[i][j];
				}
			}
			s += "\n";
		}
		s += "\n";
		return s;
	}

	public boolean validGuess(String word, int number, boolean across) {
		if(across) {
			if(this.across[number].equalsIgnoreCase(word)){
				totalWords -= 1;
				String location = positionsA[number];
				String parameters [];
				
				parameters = location.split(",");
				int x = Integer.parseInt(parameters[0]);
				int y = Integer.parseInt(parameters[1]);
				placeWord(word, x, y, across);
				
				//Now remove the question
				String q = answers[number];
				questions.remove(number + " " + q);
				AC2.removeElement(number);
				return true;
			}
		}else {
			if(this.down[number].equalsIgnoreCase(word)){
				totalWords -= 1;
				String location = positionsD[number];
				String parameters [];
				parameters = location.split(",");
				int x = Integer.parseInt(parameters[0]);
				int y = Integer.parseInt(parameters[1]);
				placeWord(word, x, y, across);
				
				String q = answers2[number];
				questions.remove(number + " " + q);
				DN2.removeElement(number);

				return true;
			}
		}
		return false;
	}

	public boolean validNumber(int number, boolean across) {
		if(across) {
			if(AC2.contains(number)) {
				return true;
			}
		}else {
			if(DN2.contains(number)) {
				return true;
			}
		}
		return false;
	}

	public boolean isGameOver() {
		if(totalWords == 0) {
			return true;
		}
		return false;
		
	}

	public void printBoard() {
		
		int bottom = 100000;
		int top = 0;
		int left = 100000;
		int right = 0;
		
		for(int i = 0; i < x; i++) {
			for(int j = 0; j < y; j++) {
				if(table[i][j] != 0 && table[i][j] != ' '){
					if(i < bottom) {
						bottom = i;
					}
				}
			}
		}
		
		for(int i = x; i > 0; i--) {
			for(int j = 0; j < y; j++) {
				if(table[i][j] != 0 && table[i][j] != ' '){
					if(i > top) {
						top = i;
					}
				}
			}
		}
		
		for(int j = 0; j < y; j++) {
			for(int i = 0; i < x; i++) {
				if(table[i][j] != 0 && table[i][j] != ' '){
					right = i+2;
					break;
				}
			}
		}
		for(int j = 0; j < y; j++) {
			for(int i = 0; i < x; i++) {
				if(table[i][j] != 0 && table[i][j] != ' '){
					left = j - 1;
					j = y;
				}
			}
		}
		
		System.out.println("");
		// Print the board
		for (int i = bottom; i < top+1; i++) {
			for (int j = left; j < right+1; j++) {
				
				if( Character.getNumericValue(table[i][j]) <= 16 && Character.getNumericValue(table[i][j]) >= 0){
					System.out.print(table[i][j]);
					continue;
				}
				
				if ((int) table[i][j] == 0 || table[i][j] == ' ') {
					System.out.print("-");
				} else {
					System.out.print(table[i][j]);
				}
			}
			System.out.println("");
		}
		System.out.println("");
	}

	Vector <String> getQuestions(){
		return questions;
	}
	
	public int findIndex(String word, boolean across) {
		if (word.equals("traveler")) {
			return 1;
		}
		int index = 0;
		if (across) {
			for (int i = 0; i < 16; i++) {
				if (this.across[i] != null) {
					if (this.across[i].equals(word)) {
						index = i;
						return index;
					}
				}
			}
		} else {
			for (int i = 0; i < 16; i++) {
				if (this.down[i] != null) {
					if (this.down[i].equals(word)) {
						index = i;
						return index;
					}
				}
			}
		}
		return -1;
	}

	public boolean doesItExists(String word, boolean across) {
		if(across) {
			for(int i = 0; i < AC.size(); i++) {
				if(AC.elementAt(i).equals(word)) {
					return true;
				}
			}
			return false;
		}else {
			for(int i = 0; i < DN.size(); i++) {
				if(DN.elementAt(i).equals(word)) {
					return true;
				}
			}
			return false;
		}
	}

	public void tempBoard() {
		positionsA[1] = "17,10";
		
		positionsD[1] = "17,10";
		
		
		
		positionsD[4] = "16,12";
		positionsA[3] = "14,13";
		positionsD[5] = "12,14";

		positionsA[2] = "23,7";

		
		placeWord("XXXXXXX", x/4, y / 8+1, true);
		placeWord("XXXXXXXX", x/4, y / 8+1, false);
		
		placeWord("XXXXXXX", 23, 7, true);
		table[x/4][y/8] = '1';
		
		table[23][6] = '2';
		
		placeWord("XXXX", x/4-1, y / 8+3, false);
		table[x/4-1][ y / 8+3-1] = '4';

		placeWord("XXXXXXXX", x/4-5, y / 8+5, false);
		table[x/4-5][y / 8+4] = '5';

		placeWord("XXXX", x/4-3, y / 8+4, true);
		table[x/4-3][y / 8+4-1] = '3';
	}
}
