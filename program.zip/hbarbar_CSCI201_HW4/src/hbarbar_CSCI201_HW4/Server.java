package hbarbar_CSCI201_HW4;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;
import java.util.Vector;

public class Server {
	char[][] table;
	int x;
	int y;
	Vector<String> words;
	Vector<Boolean> acrossOrNot = new Vector<Boolean>();

	public static void main(String[] args) {
		Server server = new Server();
		server.parse();
	}
	
	
	public void parse() {
		
		try {
			FileReader fr;
			BufferedReader br;
			Scanner scan = new Scanner(System.in);
			String filename = "data.txt";
			fr = new FileReader(filename);
			br = new BufferedReader(fr);
			String line = br.readLine();
			
			int rows = 0;
			int colum = 0;
			
			String[] parameters;
			String[] across = new String[16];
			String[] down = new String[16];
			
			String[] answers = new String[16];
			String[] answers2 = new String[16];
			
			boolean ac = true;
			//Parse the data
			while (line != null) {
				parameters = line.split("[|]");
				if(parameters[0].contentEquals("DOWN")) {
					ac = false;
				}
				if(parameters.length > 1) {
					if(ac) {
						across[Integer.parseInt(parameters[0])] = parameters[1];
						answers[Integer.parseInt(parameters[0])] = parameters[2];
						rows += parameters[1].length();
					}else{
						down[Integer.parseInt(parameters[0])] = parameters[1];
						answers2[Integer.parseInt(parameters[0])] = parameters[2];
						colum += parameters[1].length();
					}
				}
				line = br.readLine();
			}
			x = rows*2-1;
			y = colum*2-1;
			table = new char[rows*2][colum*2];
			int startX = rows;
			int startY = colum;
			
			
			
			words = new Vector<String>();
			for(int i = 0; i < 16; i++) {
				System.out.println(across[i]);
				System.out.println(down[i]);

				words.add(across[i]);
				words.add(down[i]);
				acrossOrNot.add(true);
				acrossOrNot.add(false);
			}
			/*
			placeWord(words.elementAt(2), x/2, 14, true);
			placeWord(words.elementAt(3), x/2+1, 14, false);
			placeWord(words.elementAt(4), x/2+7, 10, true);
			*/
			try{
				//generateBoard(words.elementAt(3),3);
			}finally {
				//Print the board
				for(int i = 0; i < rows*2; i++) {
					for(int j = 0; j < colum*2; j++) {
						if((int)table[i][j] == 0) {
							System.out.print("-");
						}else {
							System.out.print(table[i][j]);
						}
					}
					System.out.println("");
				}
			}
			
			
			
		} catch (IOException e) {
			e.printStackTrace();
		}
		
	}
	
	public void placeWord(String word, int x, int y, boolean across) {
		if(!across) {
			int index = 0;
			for(int i = x; index < word.length(); i++) {
				table[i][y] = word.charAt(index);
				index++;
			}
		}else {
			int index = 0;
			for(int i = y; index < word.length(); i++) {
				table[x][i] = word.charAt(index);
				index++;
			}
		}
	}
	
	public boolean validPlacement(String word, int x, int y, boolean across) {
		//first check if we are at the corners
		if( (across && (y == this.y)) ||  (!across && (x == this.x)) ){
			return false;
		}		
		//Check if it will go out of bounds
		if( (across && (word.length() + y > this.y)) || (!across &&(word.length() + x) > this.x) ) {
			return false;
		}
		//Check if anything next to it is a word
		//Check the beg and end of the word
		if(across) {
			if(word.length() + y + 1 <= this.y) {
				if((int)table[x][word.length() + y + 1] != 0) {
					return false;
				}
			}
		}else {
			if(word.length() + x + 1 <= this.x) {
				if((int)table[word.length() + x + 1][y] != 0) {
					return false;
				}
			}
		}
		//Now check if its only bounded by empty spaces
		if(across) {
			boolean valid1 = true;
			boolean valid2 = true;
			if(x != 0) {
				for(int i = y; i < word.length(); i++) {
					if((int)table[x-1][i] != 0) {
						break;
					}
					valid1 = false;
				}
			}
			if(x != this.x) {
				for(int i = y; i < word.length(); i++) {
					if((int)table[x+1][i] != 0) {
						break;
					}
					valid2 = false;
				}
			}
			if(valid1 || valid2 == false) {
				return false;
			}
		}
		if(!across) {
			if(y != 0) {
				for(int i = x; i < word.length(); i++) {
					if((int)table[i][y-1] == 0) {
						return false;
					}
				}
			}
			if(y != this.y) {
				for(int i = x; i < word.length(); i++) {
					if((int)table[i][y+1] == 0) {
						return false;
					}
				}
			}
		}
		//Now check if we can place it
		int index = x;
		if(across) {
			index = y;
			for(int i = 0; i < word.length(); i++) {
				if(word.charAt(i) != table[x][index] && (int)table[x][index] != 0 ) {
					return false;
				}
				index++;
			}
		}else{
			boolean oneCharacter = false;
			System.out.println(" ");
			for(int i = 0; i < word.length(); i++) {
				System.out.println("Examining at: " + index + " " + y + ". With: " + word.charAt(i) + " AND " + table[index][y]);
				if(word.charAt(i) == table[index][y]) {
					oneCharacter = true;
				}
				index++;
			}
			return oneCharacter;
		}
		
		return true;
	}
	
	public void removeWord(int length, int x, int y, boolean across) {
		if(across) {
			int index = y;
			for(int i = 0; i < length; i++) {
				table[x][index] = 0;
				index++;
			}
		}else {
			int index = 0;
			for(int i = y; index < length; i++) {
				table[i][y] = 0;
				index++;
			}
		}
	}
	
	public boolean generateBoard(String word, int x) {
		if(x ==  words.size()) {
			return true;
		}
		System.out.println("Trying to place: " + word);
		for(int i = 0; i < this.x; i++) {
			for(int j = 0; j < y; j++) {
				if(validPlacement(word, i , j, acrossOrNot.elementAt(x))) {
					System.out.println("Position Found at: " + i + " " + j + " for: " + word);
					placeWord(word, i, j, acrossOrNot.elementAt(x));
					if(generateBoard(words.elementAt(x+1), x+1)) {
						return true;
					}else {
						System.out.println("Position not good at: " + i + " " + j + " for: " + word);
						//removeWord(word.length(), i, j, acrossOrNot.elementAt(x));
					}
				}
			}
		}
		return false;
		//If we cannt place this word
		
		
	}
}


