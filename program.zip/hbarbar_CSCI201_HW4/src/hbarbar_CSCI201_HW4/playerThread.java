package hbarbar_CSCI201_HW4;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.Scanner;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;

public class playerThread extends Thread {

	private PrintWriter pw;
	private BufferedReader br;
	private crossword cr;
	private Lock loc;
	private Condition con;
	boolean first;
	public boolean finish;
	

	public playerThread(Socket s, crossword cr, Lock loc, Condition con, boolean first) {
		try {
			this.cr = cr;
			this.loc = loc;
			this.con = con;
			this.first = first;
			finish = false;
			pw = new PrintWriter(s.getOutputStream());
			br = new BufferedReader(new InputStreamReader(s.getInputStream()));
			this.start();
		} catch (IOException ioe) {
			System.out.println("ioe in ServerThread constructor: " + ioe.getMessage());
		}
	}

	public void sendMessage(String message) {
		pw.println(message);
		pw.flush();
	}
	
	public void run() {
		try {
			//int players;
			//Scanner sc = new Scanner(System.in);
			loc.lock();
			while(true) {
				if(first == false) {
					con.await();
				}
				while(true) {
					String line = br.readLine();
					
					cr.broadcast(line, this);						
					//if line == END then then the user is done
					if(finish) {
						first = false;
						break; 
					}
				}
				finish = false;
			}
		} catch (IOException ioe) {
			System.out.println("ioe in ServerThread.run(): " + ioe.getMessage());
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public void setFinish() {
		this.finish = true;
	}
	
	
}