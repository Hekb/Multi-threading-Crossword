package hbarbar_CSCI201_HW4;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.Scanner;

public class player extends Thread {

	private BufferedReader br;
	private PrintWriter pw;
	private String name;
	public player(String hostname, int port, String name) {
		try {
			Socket s = new Socket(hostname, port);
			br = new BufferedReader(new InputStreamReader(s.getInputStream()));
			pw = new PrintWriter(s.getOutputStream());
			this.name = name;
			this.start();
			Scanner scan = new Scanner(System.in);
			while(true) {
				String line = scan.nextLine();
				
				pw.println(line);
				pw.flush();
			}
			
		} catch (IOException ioe) {
			System.out.println("ioe in ChatClient constructor: " + ioe.getMessage());
		}
	}
	public void run() {
		try {
			while(true) {
				String line = br.readLine();
				if(!line.equals(null)) {
					if(line.contentEquals("GAME IS OVER")) {
						System.exit(0);
					}else {
						System.out.println(line);
					}
				}
				
			}
		} catch (IOException ioe) {
			System.out.println("ioe in ChatClient.run(): " + ioe.getMessage());
		}
	}
	public static void main(String [] args) {
		Scanner s = new Scanner(System.in);
		System.out.print("Enter the server hostname: ");
		String host = s.nextLine();
		System.out.print("Enter the server port: ");
		int port = s.nextInt();
		player cc = new player(host, port, "sd");
	}
}